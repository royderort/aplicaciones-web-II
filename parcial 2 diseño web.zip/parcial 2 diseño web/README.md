# Pokemon API

API desarrollada con Spring Boot que consume la PokeAPI.

## Tecnologías usadas

- Java 17
- Spring Boot
- Maven
- RestTemplate

## API externa

https://pokeapi.co/

## Endpoints

### 1. Obtener Pokémon

GET /api/pokemon/{name}

Ejemplo:

/api/pokemon/pikachu

Respuesta:

```json
{
  "name": "pikachu",
  "height": 4,
  "weight": 60
}
```

---

### 2. Top Pokémon

GET /api/pokemon/top

Respuesta:

```json
[
  "Pikachu",
  "Charizard",
  "Mewtwo"
]
```

---

### 3. Welcome

GET /api/pokemon/welcome

Respuesta:

```json
{
  "message": "Bienvenido a mi API Pokemon",
  "author": "Royder"
}
```

## Manejo de errores

Si el Pokémon no existe:

```json
{
  "status": 404,
  "error": "Pokemon no encontrado"
}
```

## Cómo ejecutar

1. Abrir el proyecto en IntelliJ
2. Ejecutar PokemonapiApplication
3. Probar endpoints en navegador o Postman