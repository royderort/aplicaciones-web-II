package com.example.pokemonapi.controller;

import com.example.pokemonapi.dto.PokemonDTO;
import com.example.pokemonapi.service.PokemonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pokemon")
public class PokemonController {

    @Autowired
    private PokemonService pokemonService;

    // Endpoint 1
    @GetMapping("/{name}")
    public PokemonDTO getPokemon(@PathVariable String name) {
        return pokemonService.getPokemon(name);
    }

    // Endpoint 2
    @GetMapping("/top")
    public List<String> topPokemon() {

        return Arrays.asList(
                "Pikachu",
                "Charizard",
                "Mewtwo"
        );
    }

    // Endpoint 3
    @GetMapping("/welcome")
    public Map<String, String> welcome() {

        return Map.of(
                "message", "Bienvenido a mi API Pokemon",
                "author", "Royder"
        );
    }
}