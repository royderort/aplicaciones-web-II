package com.example.pokemonapi.service;

import com.example.pokemonapi.dto.PokemonDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@Service
public class PokemonService {

    @Autowired
    private RestTemplate restTemplate;

    public PokemonDTO getPokemon(String name) {

        try {

            String url = "https://pokeapi.co/api/v2/pokemon/" + name;

            Map response = restTemplate.getForObject(url, Map.class);

            String pokemonName = (String) response.get("name");
            int height = (Integer) response.get("height");
            int weight = (Integer) response.get("weight");

            return new PokemonDTO(
                    pokemonName,
                    height,
                    weight
            );

        } catch (HttpClientErrorException.NotFound e) {

            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Pokemon no encontrado"
            );
        }
    }
}