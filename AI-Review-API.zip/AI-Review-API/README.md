# AI Review API

## Descripción
API REST desarrollada con FastAPI para gestionar reseñas de productos y analizar sentimientos utilizando Inteligencia Artificial.

## Tecnologías
- Python
- FastAPI
- Supabase
- Gemini API
- Uvicorn

## Instalación

```bash
git clone https://github.com/royderort/aplicaciones-web-II.git o descargar el archivo desde git hub
cd AI-Review-API

python -m venv venv

venv\Scripts\activate

pip install -r requirements.txt

ejecucion abrir la carpeta del programa en visual estudio code reemplazar el archivo .env ejecutar: uvicorn main:app --reload, dirigirse a http://127.0.0.1:8000/docs

screnshots todas las imagenes se encuentran en la carpeta docs/screnshots

video https://drive.google.com/file/d/11Z6opUuAYkf1eiN6tnhIeB3bK0z_2ZAt/view?usp=drive_link